<header id="stickyHeader">
    <div class="container">
        <div class="top-bar">
            <div class="logo">
                <a href="{{ route('index') }}">
                    <img alt="logo" src="/img/logo.png">
                </a>
            </div>
            <nav class="navbar">
                <ul class="navbar-links">
                    <li class="navbar-dropdown menu-item-children">
                        <a href="#">Demo Pages</a>
                        <ul class="sub-menu">
                            <li><a href="{{ route('index-1') }}">Demo 1</a></li>
                            <li><a href="{{ route('index-2') }}">Demo 2</a></li>
                            <li><a href="{{ route('index-3') }}">Demo 3</a></li>
                            <li><a href="{{ route('index-4') }}">Demo 4</a></li>
                        </ul>
                    </li>
                    <li class="navbar-dropdown">
                        <a href="#about"> About </a>
                    </li>
                    <li class="navbar-dropdown">
                        <a href="#services">Services</a>
                    </li>
                    <li class="navbar-dropdown">
                        <a href="#team">Team</a>
                    </li>
                    <li class="navbar-dropdown">
                        <a href="#pricing">Pricing</a>
                    </li>
                    <li class="navbar-dropdown">
                        <a href="#blog">blog</a>
                    </li>
                </ul>
            </nav>
            <a href="callto:+12344502086"><i class="flaticon-smart-phone"></i><b> +1234 450 2086</b></a>
        </div>
    </div>
</header>
