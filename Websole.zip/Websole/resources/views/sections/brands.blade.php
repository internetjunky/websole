<div class="gap">
    <div class="container">
        <div class="heading sec-title-animation animation-style2">
            <img alt="img" src="/img/heading-img.png">
            <h5 class="title-animation">Thousands of businesses use Websole</h5>
        </div>
        <div class="marquee mt-4">
            <div class="marquee-icon">
                <div class="marquee-content">
                    <div class="marquee-item">
                        <img src="/img/sponsor-img-1.png" alt="img">
                    </div>
                    <div class="marquee-item">
                        <img src="/img/sponsor-img-2.png" alt="img">
                    </div>
                    <div class="marquee-item">
                        <img src="/img/sponsor-img-3.png" alt="img">
                    </div>
                    <div class="marquee-item">
                        <img src="/img/sponsor-img-4.png" alt="img">
                    </div>
                    <div class="marquee-item">
                        <img src="/img/sponsor-img-5.png" alt="img">
                    </div>
                    <div class="marquee-item">
                        <img src="/img/sponsor-img-6.png" alt="img">
                    </div>
                    <div class="marquee-item">
                        <img src="/img/sponsor-img-7.png" alt="img">
                    </div>
                </div>
                <div class="marquee-content">
                    <div class="marquee-item">
                        <img src="/img/sponsor-img-1.png" alt="img">
                    </div>
                    <div class="marquee-item">
                        <img src="/img/sponsor-img-2.png" alt="img">
                    </div>
                    <div class="marquee-item">
                        <img src="/img/sponsor-img-3.png" alt="img">
                    </div>
                    <div class="marquee-item">
                        <img src="/img/sponsor-img-4.png" alt="img">
                    </div>
                    <div class="marquee-item">
                        <img src="/img/sponsor-img-5.png" alt="img">
                    </div>
                    <div class="marquee-item">
                        <img src="/img/sponsor-img-6.png" alt="img">
                    </div>
                    <div class="marquee-item">
                        <img src="/img/sponsor-img-7.png" alt="img">
                    </div>
                </div>
            </div>
        </div>
        <div class="marquee-text">
            <p>Join a growing group of satisfied customers who have made the switch.</p>
        </div>
    </div>
</div>
<hr>
